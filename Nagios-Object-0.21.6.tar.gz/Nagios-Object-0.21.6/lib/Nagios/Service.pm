package Nagios::Service;

our $VERSION = '0.21';

=pod

This is an empty module right now.  Please see Nagios::Object where the bulk
of Nagios::Service is generated.

=cut

1;
